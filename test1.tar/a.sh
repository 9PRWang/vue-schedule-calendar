${deploy_path}
mkdir -p ${deploy_path}/Log

## LOCATE CACHE_DIR AND MAKE IT ###
cat ./CoralReef.config.template | grep '<filepath>' | sed 's/filepath>//g'| sed 's/<//g' | xargs -I{} mkdir -p {}

rm ${deploy_path}/Config/CoralReef.config
cp ./CoralReef.config.template ${deploy_path}/Config/CoralReef.config

rm ${deploy_path}/appsettings.json
cp ./appsettings.json.template ${deploy_path}/appsettings.json

rm ${deploy_path}/log4net.config
cp ./log4net.config.template ${deploy_path}/log4net.config

cp ./CoralReef-License.xml ${deploy_path}/CoralReef-License.xml

chmod +x ${deploy_path}/CoralReef.Web*
