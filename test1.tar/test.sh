echo "#####POSTGRESQL########" >> ~/.bash_profile
echo "PG_HOME=/app/bin/pgsql" >> ~/.bash_profile
echo "PG_DATA=/app/bin/pgsql/data" >> ~/.bash_profile
echo "PG_PORT=5433" >> ~/.bash_profile
echo "PATH=.:\$PATH:\$PG_HOME/bin ">>~/.bash_profile
source ~/.bash_profile
