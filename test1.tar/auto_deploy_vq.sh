#!/bin/bash
#脚本名称:auto_deploy_vq.sh
#脚本功能:自动化部署vq系统
#版本:1.0
#注意事项:此auto_deploy_vq.sh可放在任意目录下，但CoralReef.config.template,appsettings.json.template,log4net.config.template,CoralReef-License.xml 这四个配置文件需要提前配置好与auto_deploy_vq.sh脚本放在同一目录下。

vq_path=${1}
deploy_path=${2}
vq_file="${vq_path}/publish.tar"

if [ ! -e "${deploy_path}"  ];then
	echo "解压目录不存在，开始创建..."
	mkdir -p ${deploy_path}
fi

echo "开始解压..."
echo "合并文件..."

cat ${vq_path}/publish.tar.* > ${vq_path}/publish.tar
if [ $? -eq 0 ];then
	echo "文件合并成功!!!"
else
	echo "文件合并失败!!!"
	exit 11
fi

tar -xvf ${vq_file} -C ${deploy_path}

if [ $? -eq 0 ];then
	echo "解压成功!!!"
else
	echo "解压失败!!!"
fi

echo "<------------------------------开始配置------------------------------>"

mkdir -p ${deploy_path}/Log

cat ./CoralReef.config.template | grep '<filepath>' | sed 's/filepath>//g'| sed 's/<//g' | xargs -I{} mkdir -p {}

rm ${deploy_path}/Config/CoralReef.config
cp ./CoralReef.config.template ${deploy_path}/Config/CoralReef.config

rm ${deploy_path}/appsettings.json
cp ./appsettings.json.template ${deploy_path}/appsettings.json

rm ${deploy_path}/log4net.config
cp ./log4net.config.template ${deploy_path}/log4net.config

cp ./CoralReef-License.xml ${deploy_path}/CoralReef-License.xml

chmod +x ${deploy_path}/CoralReef.Web*

if [ $? -ne 0 ];then
	echo "配置失败!!!"
	exit 12
fi

echo "<------------------------------配置结束------------------------------>"

{
varTM=`date +%Y%m%d%H%M`
${deploy_path}/CoralReef.WebSite >/dev/null 2> ../CoralReef.log.${varTM} &
}

sleep 10
result_web=`ps -ef|grep -i "CoralReef.WebSite"|grep -v grep|awk -F"/" '{print $6}'`
result_port=`netstat -tnl|grep 5000|awk '{print $4}'|awk -F":" '{print $4}'`

if [[ "${result_web}" = "CoralReef.WebSite" && "${result_port}" = "5000" ]];then
	echo "服务启动成功..."
else
	echo "服务异常请检查!!!"
fi
